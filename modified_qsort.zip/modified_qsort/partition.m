function [a1,j,count] = partition( a1,first,last )
if(first<last)
t=0;
count=0;
j=last;
i=first;
pivot=first;

while (i<j)
    while (a1(i) <= a1(pivot) && i<last)
        i=i+1;
        count=count+1;
    end
    count=count+1;
   while (a1(j) > a1(pivot))
        j=j-1;
        count=count+1;
    end
   count=count+1;
   a1(i)
   a1(j)
   if i<j
       t=a1(i);
       a1(i)=a1(j);
       a1(j)=t;
       count=count+1;
  
       
   
end
count=count+1;


a1

 

 
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
end
if i~=pivot
temp=a1(j);
a1(j)=a1(pivot);
a1(pivot)=temp;
end
a1
j

end
end