function [ a,c ] = f_qsort_mod( a,first,last)
%UNTITLED11 Summary of this function goes her
c=0;

c2=0;c3=0;
if first < last
    
     if (last-first)<=12
     [a,c2]=f_insrt_mod( a,first,last);
     c=c2;
     return
     end
         
[a,index,c1]= partition( a,first,last ); 
first
index-1



if (index-first)>=12
[a,c2]=f_qsort_mod( a,first,index-1 );
else
    [a,c2]=f_insrt_mod( a,first,index-1);
end  
    
if (last-index)>=12
        [a,c3]=f_qsort_mod( a,first,index-1 ); 

else 
    [a,c2]=f_insrt_mod( a,first,index-1);
end


      

c=c2+c1+c3;
a(index)

%c=c1+c2+c3;

end


end



