
k=1;
xele=zeros(1,20);
ycomp=zeros(1,20);
ycompmod=zeros(1,20);

for n=10:10:200

a= round(rand(1,n)*100);
b=a;
xele(k)= n;

[a,ycomp(k)]= f_qsort(a,1,n );
[b,ycompmod(k)]=f_qsort_mod(b,1,n);
k=k+1;
 end
a
plot(xele,ycomp,xele,ycompmod )


xlabel('No of element')
ylabel('No of comparison')
legend('quicksort sort','moifiedquick sort')
title('analysis for sorting algorithm')
grid

