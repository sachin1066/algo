comp=0;
k=1;
binwt=80;
item=zeros(1,100);
bfit=zeros(1,100);nfit=zeros(1,100);
ffit=zeros(1,100);



bfit_time=zeros(1,100);nfit_time=zeros(1,100);
ffit_time=zeros(1,100);

for n=10:10:1000
    a=mod(round(rand(1,n)*100),binwt);
    a
    item(k)=n;
 [nfit_time(k),bfit(k)]=bestfit(a,n,binwt);
 [nfit_time(k),nfit(k)]=nextfit(a,n,binwt);
 [ffit_time(k),ffit(k)]=firstfit(a,n,binwt);
   
   
   bfit(k)
   ffit(k)
   nfit(k)
    k=k+1;
end
plot(item,bfit,item,nfit,item,ffit)
legend('bfit','nfit','ffit')
xlabel('no of item')
ylabel('comprision reqired')
title('number of bin')


%plot(item,ffit);
figure
plot(item,bfit_time,item,nfit_time,item,ffit_time)
legend('bfit','nfit','ffit')
xlabel('no of item')
ylabel('comprision reqired')
title('time of execution')


