
function [comp, count ] = firstfit( a,n,binwt )
firstfin_bin_pos=zeros(1,n);
b=zeros(1,n);
count=0;
comp=0;
for i=1:n
b(i)=binwt;
end
for i=1:n
    for j=1:i
        comp=comp+1;
        if(a(i)<=b(j))
            
            b(j)=b(j)-a(i);
            a(i)=-1;
            firstfin_bin_pos(i)=j;
            break;
        end
        
    end
end
     for j=1:n
         if b(j)~=binwt
             count=count+1;
         end
     end 
        
 firstfin_bin_pos   
end


