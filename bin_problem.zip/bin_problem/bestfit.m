
function [ comp,count ] = bestfit(a,n,binwt )


k=0;
d=80;
min=binwt;
%c=zeros(1,10);
b=zeros(1,n);
c=zeros(1,n);
count=0;
comp=0;
for i=1:n
b(i)=binwt;
k=0;

end
for i=1:n
    for j=1:i
        comp=comp+1;
        if b(j)==a(i)
            b(j)=0;
            c(i)=j;
            a(i)=-1;
           
            break;
        elseif and( b(j)>a(i),min>=b(j))
            comp=comp+1;
           min=b(j);
            k=j;
            
        end
    end
    if k~=0
    b(k)=b(k)-a(i);
    c(i)=k;
     min=80;
     k=0;
     a(i)=-1;
     
    
    end
end

for i=1:n
if b(i)~=binwt
count=count+1;
end
end
c


end

