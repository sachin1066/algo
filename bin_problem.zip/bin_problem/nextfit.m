function [ comp,count ] = nextfit( a,n,binwt )
nextfit_bin_pos=zeros(1,n);
b=zeros(1,n);
count=1;
comp=0;
for i=1:n
b(i)=binwt;
end
j=1;

    for i=1:n
        comp=comp+1;
     if(b(j)>=a(i))
        b(j)=b(j)-a(i);
        
        a(i)=-1;
        
        nextfit_bin_pos(i)=j;
          
    else
        j=j+1;
            
            b(j)=b(j)-a(i);
            a(i)=-1;
           count=count+1;
            nextfit_bin_pos(i)=j;
    end


    end
    nextfit_bin_pos
end