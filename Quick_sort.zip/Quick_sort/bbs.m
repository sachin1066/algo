
k=1
t=0;
xele=zeros(1,10);
ycomp=zeros(1,10);


for n=10:10:100
a= round(rand(1,n)*500)
xele(k)= n
%-----------------------------------------

%---------------------------------------------
[a ,r]=  quicksort( a,1,n )
ycomp(k)=r;

k=k+1
end
plot(xele, ycomp)

