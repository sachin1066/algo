a=round(rand(1,10)*100)
[a ,tmp ]=quicksort( a,1,10 );
a
tmp
