function [ a,c ] = quicksort( a,p,q )
%UNTITLED11 Summary of this function goes her
c=0;

if p<q
    
[a, pv ,c1 ]= partition1( a,p,q ); 
[a ,c2]=quicksort( a,p,pv-1 );
[a ,c3]=quicksort( a,pv+1,q );
c=c1+c2+c3;

end


end

