function [a ,i ,comp ] = partition1( a,p1,q1 )
i=p1;
pos=i;
t=0;
 
comp=0;
 
for j=i+1:q1
     comp=comp+1;
      if a(j)<a(pos)
        i=i+1;
        t=a(i);
        a(i)=a(j);
        a(j)=t;
    end
end

t=a(i);
a(i)=a(pos);
a(pos)=t;

%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here


end

