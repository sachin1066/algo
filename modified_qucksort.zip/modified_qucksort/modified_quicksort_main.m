
k=1;
t=0;
noele=zeros(1,9);
cmp_q=zeros(1,9);
cmp_mq=zeros(1,9);




for n=20:10:100
    a= round(rand(1,10)*100)
    b=a
    noele(k)=n;
    [a,comp_q]=f_qsort(a,1,n );
    %[b,comp_mq]=f_qsort_mod( b,1,n );

k=k+1;
end
%plot(noele,cmp_q,'r',noele,comp_mq,'g')
