function [ ct ] = f_bsort(a1,ne)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
ct=0;
t=0;
for i=1:ne-1
   for j=1:ne-i
       ct=ct+1;
       if (a1(j)>a1(j+1))
           t=a1(j)
           a1(j)=a1(j+1)
           a1(j+1)=t
       end   
   end
end




