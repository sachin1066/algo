% *********************** Bubble sort Program *********** %
ct=0;
k=1;
t=0;
noele=zeros(1,10);
cmp1=zeros(1,10);
cmp2=zeros(1,10);
for n1=10:10:100 
    noele(k)=n1;
  a=round(rand(1,n1)*100);
cmp1(k)=f_bsort(a,n1);
%a=sort(a);
cmp2(k)=f_mbsort(a,n1);
ct=0;
k=k+1;
end
plot(noele,cmp1,'b-',noele,cmp2,'r')
xlabel('No of element')
ylabel('No of comparison')
legend('Bubble sort','Modified bubble sort')
title('Bubble sort VS Modified bubble sort')
grid